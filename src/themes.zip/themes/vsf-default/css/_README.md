# Documentation
Please read the docs before working with stylesheets.

[Working with stylesheets](https://github.com/DivanteLtd/vue-storefront/blob/master/doc/Working%20with%20stylesheets%20(CSS).md) -  how to use and extend stylesheets in Vue Storefront.