<template>
    <div class="dv3">
      <div class="dv3_inner">
  
        <!-- 1 -->
        <div class="bg bg1 bg_sec">
          <!-- <h1 class="collection-hd">Human Abstract</h1> -->
          <img class="head-img-cl" src="../assets/collection/ha_text.svg">
          <a href="./one-liner-winter-2023-24.html" class="section_btn">
            <div class="">
              <p>See All</p>
            </div>
          </a>
          <img class="model_img" src="/assets/collection/collection-1.webp" />
        </div>
  
        <div class="bg bg1 bg_sec">
           <!-- <h1 class="collection-hd">Human Abstract</h1> -->
           <img class="head-img-cl" src="../assets/collection/ha_text.svg">
          <a href="one-liner-winter-2023-24.html" class="section_btn">
            <div class="">
              <p>See All</p>
            </div>
          </a>
          <img class="model_img" src="/assets/collection/collection-1.webp" />
        </div>
  
        <div class="bg bg1 bg_sec">
           <!-- <h1 class="collection-hd">Human Abstract</h1> -->
           <img class="head-img-cl" src="../assets/collection/ha_text.svg">
          <a href="one-liner-winter-2023-24.html" class="section_btn">
            <div class="">
              <p>See All</p>
            </div>
          </a>
          <img class="model_img" src="/assets/collection/collection-1.webp" />
        </div>
  
      
        <!-- 2 -->
        <div class="bg bg2 bg_sec">
           <!-- <h1 class="collection-hd">Human Abstract</h1> -->
           <img class="head-img-cl" src="../assets/collection/ha_text.svg">
          <a href="one-liner-winter-2023-24.html" class="section_btn">
            <div class="">
              <p>See All</p>
            </div>
          </a>
  
          <img class="model_img" src="/assets/collection/collection-2.webp" />
        </div>
  
        <div class="bg bg2 bg_sec">
           <!-- <h1 class="collection-hd">Human Abstract</h1> -->
           <img class="head-img-cl" src="../assets/collection/ha_text.svg">
          <a href="one-liner-winter-2023-24.html" class="section_btn">
            <div class="">
              <p>See All</p>
            </div>
          </a>
  
          <img class="model_img" src="/assets/collection/collection-2.webp" />
        </div>
  
        <div class="bg bg2 bg_sec">
           <!-- <h1 class="collection-hd">Human Abstract</h1> -->
           <img class="head-img-cl" src="../assets/collection/ha_text.svg">
          <a href="one-liner-winter-2023-24.html" class="section_btn">
            <div class="">
              <p>See All</p>
            </div>
          </a>
  
          <img class="model_img" src="/assets/collection/collection-2.webp" />
        </div>
  
  
        <!-- 3 -->
        <div class="bg bg3 bg_sec">
           <!-- <h1 class="collection-hd">Human Abstract</h1> -->
           <img class="head-img-cl" src="../assets/collection/ha_text.svg">
          <a href="one-liner-winter-2023-24.html" class="section_btn">
            <div class="">
              <p>See All</p>
            </div>
          </a>
          <img class="model_img" src="/assets/collection/collection-3.webp" />
        </div>
  
        <div class="bg bg3 bg_sec">
           <!-- <h1 class="collection-hd">Human Abstract</h1> -->
           <img class="head-img-cl" src="../assets/collection/ha_text.svg">
          <a href="one-liner-winter-2023-24.html" class="section_btn">
            <div class="">
              <p>See All</p>
            </div>
          </a>
          <img class="model_img" src="/assets/collection/collection-3.webp" />
        </div>
  
        <div class="bg bg3 bg_sec">
           <!-- <h1 class="collection-hd">Human Abstract</h1> -->
           <img class="head-img-cl" src="../assets/collection/ha_text.svg">
          <a href="one-liner-winter-2023-24.html" class="section_btn">
            <div class="">
              <p>See All</p>
            </div>
          </a>
          <img class="model_img" src="/assets/collection/collection-3.webp" />
        </div>
  
  
        <!-- 4 -->
        <div class="bg bg4 bg_sec">
           <!-- <h1 class="collection-hd">Human Abstract</h1> -->
           <img class="head-img-cl" src="../assets/collection/ha_text.svg">
          <a href="one-liner-winter-2023-24.html" class="section_btn">
            <div class="">
              <p>See All</p>
            </div>
          </a>
          <img class="model_img" src="/assets/collection/collection-4.webp" />
        </div>
  
        <div class="bg bg4 bg_sec">
         <!-- <h1 class="collection-hd">Human Abstract</h1> -->
         <img class="head-img-cl" src="../assets/collection/ha_text.svg">
          <a href="one-liner-winter-2023-24.html" class="section_btn">
            <div class="">
              <p>See All</p>
            </div>
          </a>
          <img class="model_img" src="/assets/collection/collection-4.webp" />
        </div>
  
        <div class="bg bg4 bg_sec">
           <!-- <h1 class="collection-hd">Human Abstract</h1> -->
           <img class="head-img-cl" src="../assets/collection/ha_text.svg">
          <a href="one-liner-winter-2023-24.html" class="section_btn">
            <div class="">
              <p>See All</p>
            </div>
          </a>
          <img class="model_img" src="/assets/collection/collection-4.webp" />
        </div>
  
  
        <!-- 5 -->
        <div class="bg bg5 bg_sec">
           <!-- <h1 class="collection-hd">Human Abstract</h1> -->
           <img class="head-img-cl" src="../assets/collection/ha_text.svg">
          <a href="one-liner-winter-2023-24.html" class="section_btn">
            <div class="">
              <p>See All</p>
            </div>
          </a>
          <img class="model_img" src="/assets/collection/collection-5.webp" />
        </div>
  
        <div class="bg bg5 bg_sec">
           <!-- <h1 class="collection-hd">Human Abstract</h1> -->
           <img class="head-img-cl" src="../assets/collection/ha_text.svg">
          <a href="one-liner-winter-2023-24.html" class="section_btn">
            <div class="">
              <p>See All</p>
            </div>
          </a>
          <img class="model_img" src="/assets/collection/collection-5.webp" />
        </div>
  
        <div class="bg bg5 bg_sec">
           <!-- <h1 class="collection-hd">Human Abstract</h1> -->
           <img class="head-img-cl" src="../assets/collection/ha_text.svg">
          <a href="one-liner-winter-2023-24.html" class="section_btn">
            <div class="">
              <p>See All</p>
            </div>
          </a>
          <img class="model_img" src="/assets/collection/collection-5.webp" />
        </div>
  
        <!-- 6 -->
        <div class="bg bg6 bg_sec">
           <!-- <h1 class="collection-hd">Human Abstract</h1> -->
           <img class="head-img-cl" src="../assets/collection/ha_text.svg">
          <a href="one-liner-winter-2023-24.html" class="section_btn">
            <div class="">
              <p>See All</p>
            </div>
          </a>
          <img class="model_img" src="/assets/collection/collection-6.webp" />
        </div>
  
        <div class="bg bg6 bg_sec">
           <!-- <h1 class="collection-hd">Human Abstract</h1> -->
          <img class="head-img-cl" src="../assets/collection/ha_text.svg">
          <a href="one-liner-winter-2023-24.html" class="section_btn">
            <div class="">
              <p>See All</p>
            </div>
          </a>
          <img class="model_img" src="/assets/collection/collection-6.webp" />
        </div>
  
        <div class="bg bg6 bg_sec">
          <!-- <h1 class="collection-hd">Human Abstract</h1> -->
          <img class="head-img-cl" src="../assets/collection/ha_text.svg">
          <a href="one-liner-winter-2023-24.html" class="section_btn">
            <div class="">
              <p>See All</p>
            </div>
          </a>
          <img class="model_img" src="/assets/collection/collection-6.webp" />
        </div>
  
        <!-- 7 -->  
        <div class="bg bg7 bg_sec">
           <!-- <h1 class="collection-hd">Human Abstract</h1> -->
           <img class="head-img-cl" src="../assets/collection/ha_text.svg">
          <a href="one-liner-winter-2023-24.html" class="section_btn">
            <div class="">
              <p>See All</p>
            </div>
          </a>
          <img class="model_img" src="/assets/collection/collection-7.webp" />
        </div>
  
        <div class="bg bg7 bg_sec">
           <!-- <h1 class="collection-hd">Human Abstract</h1> -->
           <img class="head-img-cl" src="../assets/collection/ha_text.svg">
          <a href="one-liner-winter-2023-24.html" class="section_btn">
            <div class="">
              <p>See All</p>
            </div>
          </a>
          <img class="model_img"  src="/assets/collection/collection-7.webp" />
        </div>
  
        <div class="bg bg7 bg_sec">
           <!-- <h1 class="collection-hd">Human Abstract</h1> -->
           <img class="head-img-cl" src="../assets/collection/ha_text.svg">
          <a href="one-liner-winter-2023-24.html" class="section_btn">
            <div class="">
              <p>See All</p>
            </div>
          </a>
          <img class="model_img" src="/assets/collection/collection-7.webp" />
        </div>
  
  
      </div>
    </div>
  </template>
  <script>
  export default {
  
  };
  </script>
  <style>
  body {
    margin: 0;
  }
  .dv3 {
    width: 100%;
    min-height: 350vh;
    position: relative;
  }
  .dv3_inner {
    top: 0;
    position: sticky;
    position: -webkit-sticky;
    
    width: 100%;
    height: 100vh;
    background:url('../assets/collection/collection_bg1.png');
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center;
  }
  .bg {
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
    left: 0;
    opacity: 0;
    transition: opacity 0.3s;
  }
  .bg.active {
    opacity: 1;
  }
  .bg .model_img{
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: top;
    position: absolute;
    top: 0;
    z-index: -1;
  }
  h1.collection-hd {
    position: absolute;
    top: 45%;
    left: 90px;
    color: #FFFF;
    font-size: 67px;
  }
  .section_btn {
    background-color: #FFF;
    border-color: #fff;
    border: 1px solid #FFF;
    backdrop-filter: blur(2px);
    color: #000;
    font-weight: 400;
    padding: 16px 30px;
    width: -moz-fit-content;
    width: fit-content;
    font-size: 15px;
    text-transform: uppercase;
    letter-spacing: 1px;
    display: block;
    margin: auto;
    margin-top: 30px;
    position: relative;
    overflow: hidden;
    width: 100%;
    max-width: 92px;
    position: absolute;
    top: 57%;
    left: 15%;
  }
  .section_btn:hover {
    background: #00000029;
    color: #FFF;
    border: 1px solid #FFF;
  }
  .section_btn div {
    width: 100%;
    float: left;
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;
  }
  .section_btn div p {
    margin: 0;
    margin-left: 12px;
    transition: all 0.4s;
  }
  .section_btn:hover div p {
    margin-left: -6px;
  }
  .section_btn div img {
    width: 20px;
    margin-left: 7px;
    display: none;
  }
  .section_btn div::after {
    content: '';
    background-image: url('../assets/icons/chevron-1.svg');
    position: absolute;
    width: 20px;
    height: 20px;
    top: -2px;
    right: -12px;
    background-size: cover;
    opacity: 0;
    transition: all 0.4s;
  }
  .section_btn:hover div::after {
    opacity: 1;
  }
  .head-img-cl {
      width: 700px !important;
      z-index: 10;
      position: absolute;
      top: 50%;
      left: 3%;
      height: auto !important; 
  }
  </style>