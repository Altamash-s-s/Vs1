<template>
    <div id="home">

    <div class="fold_main">
      <!-- fold 1 -->
      <div class="header-main snap">
        <video autoplay muted loop>
          <source src="/assets/home/human_abstract_video.mp4" type="video/mp4">
        </video>
      </div>
      <!-- fold 2 -->
      <div class="parallax-section snap">
        <div class="parallax-content">
          <div class="head-text">
            <h2 class="text" data-aos="slide-down" data-aos-ease='ease' data-aos-duration="1500" data-aos-delay='1000'>
              One liner</h2>

            <a href="./Collection" class="section_btn">
              <div class="">
                <p>See More</p>
              </div>
            </a>
          </div>
        </div>
        <div class="parallax-image section1"></div>
      </div>
      <!-- fold 3 -->
      <div class="parallax-section snap">
        <div class="parallax-content">
          <div class="head-text">
            <!-- <h6 class="para">EYEWEAR</h6> -->
            <h2 class="text" data-aos="slide-down" data-aos-ease='ease' data-aos-duration="1500" data-aos-delay='1000'>
              HA - WINTER</h2>
            <a href="#" class="section_btn">
              <div class="">
                <p>See More</p>
              </div>
            </a>

          </div>
        </div>
        <div class="parallax-image section2"></div>
      </div>
      <!-- fold 4 -->
      <div class="parallax-section snap">
        <div class="parallax-content">
          <div class="head-text">
            <!-- <h6 class="para">EYEWEAR</h6> -->
            <h2 class="text" data-aos="slide-down" data-aos-ease='ease' data-aos-duration="1500" data-aos-delay='1000'>
              ABSTRACT</h2>
            <a href="#" class="section_btn">
              <div class="">
                <p>See More</p>
              </div>
            </a>

          </div>
        </div>
        <div class="parallax-image section3"></div>
      </div>
      <!-- fold 5 -->
      <div class="parallax-section snap">
        <div class="parallax-content">
          <div class="head-text">
            <!-- <h6 class="para">EYEWEAR</h6> -->
            <h2 class="text" data-aos="slide-down" data-aos-ease='ease' data-aos-duration="1500" data-aos-delay='1000'>
              WINTER POP</h2>
            <a href="#" class="section_btn">
              <div class="">
                <p>See More</p>
              </div>
            </a>
          </div>
        </div>
        <div class="parallax-image section4"></div>
      </div>
      <!-- fold 6 -->
      <div class="parallax-section snap">
        <div class="parallax-content">
          <div class="head-text">
            <!-- <h6 class="para">EYEWEAR</h6> -->
            <h2 class="text" data-aos="slide-down" data-aos-ease='ease' data-aos-duration="1500" data-aos-delay='1000'>
              HA WINTER CRAFT</h2>
            <a href="#" class="section_btn">
              <div class="">
                <p>See More</p>
              </div>
            </a>


          </div>

          <div id="audio-control" class="muted">
              <img src="/assets/icons/unmute.png" class="mute_icon">
              <img src="/assets/icons/mute.png" class="unmute_icon">
            </div>

            <div class="video-control">
              <div class="video-control-play">
                <div class="video-control-symbol" aria-hidden="true">
                  <img class="play-img" src="/assets/icons/play-1.png"></div>
              </div>
              <div class="video-control-pause">
                <div class="video-control-symbol" aria-hidden="true">
                  <img class="pause-img" src="/assets/icons/pause-1.png"></div>
              </div>
            </div>

        </div>
        <div class="parallax-image section5">
          <!-- <video src="../assets/icons/home-video.mp4" playsinline autoplay muted loop></video> -->
          <video id="banner_video" autoplay control muted loop>
            <source src="/assets/home/home-video.mp4" type="video/mp4" />
          </video>
        </div>

      </div>
      <!-- fold 7 -->
      <div class="parallax-section snap">
        <div class="parallax-content">
          <div class="head-text">
            <h2 class="text" data-aos="slide-down" data-aos-ease='ease' data-aos-duration="1500" data-aos-delay='1000'>
            HA WINTER ART </h2>
            <a href="#" class="section_btn">
              <div class="">
                <p>See More</p>
              </div>
            </a>
          </div>

        </div>
        <div class="parallax-image section6"></div>
      </div>
      <!-- fold 8 -->
      <div class="marquee-box frame snap">

        <div class="text">
          <span>E</span>
          <span>L</span>
          <span>A</span>
          <span>S</span>
          <span></span>
          <span></span>
          <span>E</span>
          <span>L</span>
          <span>A</span>
          <span>S</span>
          <span></span>
          <span></span>
          <span>E</span>
          <span>L</span>
          <span>A</span>
          <span>S</span>
          <span></span>
          <span></span>
          <span>E</span>
          <span>L</span>
          <span>A</span>
          <span>S</span>
          <span></span>
          <span></span>
          <span>E</span>
          <span>L</span>
          <span>A</span>
          <span>S</span>
          <span></span>
          <span></span>
          <span>E</span>
          <span>L</span>
          <span>A</span>
          <span>S</span>
          <span></span>
          <span></span>
          <span>E</span>
          <span>L</span>
          <span>A</span>
          <span>S</span>
          <span></span>
          <span></span>
          <span>E</span>
          <span>L</span>
          <span>A</span>
          <span>S</span>
          <span></span>
          <span></span>
          <span>E</span>
          <span>L</span>
          <span>A</span>
          <span>S</span>
          <span></span>
          <span></span>
          <span>E</span>
          <span>L</span>
          <span>A</span>
          <span>S</span>
          <span></span>
          <span></span>
          <span>E</span>
          <span>L</span>
          <span>A</span>
          <span>S</span>
          <span></span>
          <span></span>
          <span>E</span>
          <span>L</span>
          <span>A</span>
          <span>S</span>
          <span></span>
          <span></span>
          <span>E</span>
          <span>L</span>
          <span>A</span>
          <span>S</span>
          <span></span>
          <span></span>
          <span>E</span>
          <span>L</span>
          <span>A</span>
          <span>S</span>
          <span></span>
          <span></span>
          <span>E</span>
          <span>L</span>
          <span>A</span>
          <span>S</span>
          <span></span>
          <span></span>
          <span>E</span>
          <span>L</span>
          <span>A</span>
          <span>S</span>
          <span></span>
          <span></span>
          <span>E</span>
          <span>L</span>
          <span>A</span>
          <span>S</span>
          <span></span>
          <span></span>
          <span>E</span>
          <span>L</span>
          <span>A</span>
          <span>S</span>
          <span></span>
          <span></span>
          <span>E</span>
          <span>L</span>
          <span>A</span>
          <span>S</span>
          <span></span>
          <span></span>
          <span>E</span>
          <span>L</span>
          <span>A</span>
          <span>S</span>
          <span></span>
          <span></span>
          <span>E</span>
          <span>L</span>
          <span>A</span>
          <span>S</span>
          <span></span>
          <span></span>
          <span>E</span>
          <span>L</span>
          <span>A</span>
          <span>S</span>
          <span></span>
          <span></span>
          <span>E</span>
          <span>L</span>
          <span>A</span>
          <span>S</span>
          <span></span>
          <span></span>
          <span>E</span>
          <span>L</span>
          <span>A</span>
          <span>S</span>
          <span></span>
          <span></span>
          <span>E</span>
          <span>L</span>
          <span>A</span>
          <span>S</span>
          <span></span>
          <span></span>
          <span>E</span>
          <span>L</span>
          <span>A</span>
          <span>S</span>
        </div>

        <div class="parallax-content sale">

          <div class="head-text sl-hd">
            <h2 class="text sl-txt" data-aos="slide-down" data-aos-ease='ease' data-aos-duration="1500"
              data-aos-delay='1000'>
              SALE</h2>
            <a href="/default/sale.html" class="section_btn sale-btn">
              <div class="">
                <p>See More</p>
              </div>
            </a>

          </div>
        </div>

      </div>
    </div>

  </div>
</template>

<script>
// query constructor
import { isServer, onlineHelper } from '@vue-storefront/core/helpers'
import LazyHydrate from 'vue-lazy-hydration'

// Theme core components
import ProductListing from 'theme/components/core/ProductListing'
  import HeadImage from 'theme/components/core/blocks/MainSlider/HeadImage'
// Theme local components
import Onboard from 'theme/components/theme/blocks/Home/Onboard'
import PromotedOffers from 'theme/components/theme/blocks/PromotedOffers/PromotedOffers'
import TileLinks from 'theme/components/theme/blocks/TileLinks/TileLinks'
import { Logger } from '@vue-storefront/core/lib/logger'
import { mapGetters } from 'vuex'
import config from 'config'
import { registerModule } from '@vue-storefront/core/lib/modules'
import { RecentlyViewedModule } from '@vue-storefront/core/modules/recently-viewed'
// import '../css/home.css';
export default {
  data () {
    return {
      loading: true
    }
  },
  components: {
    HeadImage,
    Onboard,
    ProductListing,
    PromotedOffers,
    TileLinks,
    LazyHydrate
  },
  computed: {
    ...mapGetters('user', ['isLoggedIn']),
    ...mapGetters('homepage', ['getEverythingNewCollection']),
    categories () {
      return this.getCategories
    },
    isOnline () {
      return onlineHelper.isOnline
    },
    isLazyHydrateEnabled () {
      return config.ssr.lazyHydrateFor.some(
        field => ['homepage', 'homepage.new_collection'].includes(field)
      )
    }
  },
  beforeCreate () {
    registerModule(RecentlyViewedModule)
  },
  async beforeMount () {
    if (this.$store.state.__DEMO_MODE__) {
      const onboardingClaim = await this.$store.dispatch('claims/check', { claimCode: 'onboardingAccepted' })
      if (!onboardingClaim) { // show onboarding info
        this.$bus.$emit('modal-toggle', 'modal-onboard')
        this.$store.dispatch('claims/set', { claimCode: 'onboardingAccepted', value: true })
      }
    }
  },
  mounted () {
    if (!this.isLoggedIn && localStorage.getItem('redirect')) this.$bus.$emit('modal-show', 'modal-signup')
    //------------------------------------- Custom JS Code START Here
  //--------------------------- Snap Scroll Code START
    var selector = ".snap";
    var $slides = $(selector);
    var currentSlide = 0;
    var isAnimating = false;

    var stopAnimation = function () {
      setTimeout(function () {
        isAnimating = false;
      }, 0);
    };

    var bottomIsReached = function ($elem) {
      var rect = $elem[0].getBoundingClientRect();
      return rect.bottom <= $(window).height();
    };

    var topIsReached = function ($elem) {
      var rect = $elem[0].getBoundingClientRect();
      return rect.top >= 0; 
    };

    document.addEventListener(
      "wheel",
      function (event) {
        var $currentSlide = $($slides[currentSlide]);

        if (isAnimating) {
          event.preventDefault();
          return;
        }

        var direction = -event.deltaY;

        if (direction < 0) {

          if (currentSlide + 1 >= $slides.length) return;
          if (!bottomIsReached($currentSlide)) return;
          event.preventDefault();
          currentSlide++;
          var $slide = $($slides[currentSlide]);
          var offsetTop = $slide.offset().top;
          isAnimating = true;

          $("html, body").animate(
            {
              scrollTop: offsetTop - 0
            },
          1000, 
            stopAnimation
          );
        } else {
      
          if (currentSlide - 1 < 0) return;
          if (!topIsReached($currentSlide)) return;
          event.preventDefault();
          currentSlide--;
          var $slide = $($slides[currentSlide]);
          var offsetTop = $slide.offset().top;
          isAnimating = true;
          $("html, body").animate(
            {
              scrollTop: offsetTop - 0
            },
          1000, 
            stopAnimation
          );
        }
      },
      { passive: false }
    );
  //--------------------------- Snap Scroll Code END
    var parallax, speed;
    parallax = document.querySelectorAll('.parallax-image');
    speed = 0.3;
    window.onscroll = function () {
      return [].slice.call(parallax).forEach(function (el, i) {
        var dist;
        dist = $(window).scrollTop() - $(el).offset().top;
        return $(el).css('top', dist * speed + 'px');
      });
    };
    $('#audio-control').click(function () {
        if ($("#banner_video").prop('muted')) {
          $("#banner_video").prop('muted', false);
          $('.mute_icon').show();
          $('.unmute_icon').hide();
        } else {
          $("#banner_video").prop('muted', true);
          $('.mute_icon').hide();
          $('.unmute_icon').show();
        }
    });
    const videoElement = document.querySelector('#banner_video') ;
    const playPauseButton = document.querySelector('.video-control'); 
    playPauseButton.addEventListener('click', () => {
      playPauseButton.classList.toggle('playing');
      if (playPauseButton.classList.contains('playing')) {
        videoElement.pause();
      }
      else {
        videoElement.play();
      }
    });
    videoElement.addEventListener('ended', () => {
      playPauseButton.classList.remove('playing');
    });
    window.addEventListener('load', videoScroll);
    window.addEventListener('scroll', videoScroll);
    function videoScroll() {
      var videoElements = document.querySelectorAll('#banner_video[autoplay]');
      if (videoElements.length > 0) {
        var windowHeight = window.innerHeight;
        videoElements.forEach(function (thisVideoEl) {
          var videoElement = thisVideoEl ; // Cast to HTMLVideoElement
          var videoHeight = videoElement.clientHeight;
          var videoClientRect = videoElement.getBoundingClientRect().top;
          if (videoClientRect <= (windowHeight - videoHeight * 0.10) && videoClientRect >= -videoHeight * 0.10) {
            videoElement.play();
          } else {
            videoElement.pause();
          }
        });
      }
    }
    //------------------------------------- Custom JS Code END Here
  },
  watch: {
    isLoggedIn () {
      const redirectObj = localStorage.getItem('redirect')
      if (redirectObj) this.$router.push(redirectObj)
      localStorage.removeItem('redirect')
    }
  },
  async asyncData ({ store, route, context }) { // this is for SSR purposes to prefetch data
    if (context) context.output.cacheTags.add(`home`)
    Logger.info('Calling asyncData in Home Page (core)')()

    await Promise.all([
      store.dispatch('homepage/fetchNewCollection'),
      store.dispatch('promoted/updateHeadImage'),
      store.dispatch('promoted/updatePromotedOffers')
    ])
  },
  beforeRouteEnter (to, from, next) {
    if (!isServer && !from.name) { // Loading products to cache on SSR render
      next(vm =>
        vm.$store.dispatch('homepage/fetchNewCollection').then(res => {
          vm.loading = false
        })
      )
    } else {
      next()
    }
  },
  setup() {
    onMounted(() => {
    });
  },
  metaInfo () {
    return {
      title: this.$route.meta.title || this.$i18n.t('Home Page'),
      meta: this.$route.meta.description ? [{ vmid: 'description', name: 'description', content: this.$route.meta.description }] : []
    }
  }
}
</script>

<style lang="scss" scoped>
.new-collection {
    @media (max-width: 767px) {
      padding-top: 0;
    }
  }
// .fold_main {
//     overflow: hidden;
// }
.header-main video {
    width: 100%;
}
.icon-user {
    width: auto;
    height: 20px;
    opacity: 0;
    transition: all 0.6s;
    margin-right: 0px;
}

.icon-user button {
    padding: 0;
    margin: 0;
}
.icon-user-show {
    opacity: 1 !important;
}
.icon-shopping-show {
    opacity: 1 !important;
}
.hambrgr {
    width: 10%;
    opacity: 0;
    transition: all 0.6s;
    margin-left: 10px;
}
.icon-shopping {
    width: auto;
    height: 20px;
    opacity: 0;
    transition: all 0.6s;
}
.icon-shopping button {
    padding: 0;
    margin: 0;
}
.hambrgr_show {
    opacity: 1 !important;
}
body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
}
.mute_icon {
    display: none;
}
.section {
    width: 100%;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    background-size: cover;
    background-repeat: no-repeat;
    background: linear-gradient(180deg, transparent 38%, rgba(0, 0, 0, .01) 44%, rgba(0, 0, 0, .03) 51%, rgba(0, 0, 0, .06) 59%, rgba(0, 0, 0, .13) 66%, rgba(0, 0, 0, .25) 74%, rgba(0, 0, 0, .5) 91%);
    background-attachment: fixed;
}
.section1 {
    background-image: url('../assets/home/hs2.png');
}
.section2 {
    background-image: url('../assets/home/hs6.png');
}
.section3 {
    background-image: url('../assets/home/hs1.png');
}
.section4 {
    background-image: url('../assets/home/hs11.png');
}
.section6 {
    background-image: url('../assets/home/hs13.png');
}
h2.text {
    margin-top: -10px;
    font-size: 30px;
    line-height: 2.25rem;
    color: #FFFF;
    transform: translateZ(-2px) scale(1.2);
    /* text-shadow: 2px 2px 5px rgb(10 5 5 / 50%); */
    letter-spacing: 5px;
}
h6.para {
    font-size: .75rem;
    letter-spacing: 1px;
    line-height: 0rem;
    color: #FFFF;
    /* text-shadow: 2px 2px 5px rgb(10 5 5 / 50%); */
    display: flex;
    justify-content: center;
    font-size: 16px;
    letter-spacing: 5px;
}
.btn-home {
    font-weight: 600;
    height: 3rem;
    letter-spacing: 0;
    min-width: 6.0625rem;
    padding: 0.28125rem 1.3125rem;
    text-transform: uppercase;
    transition: color .2s, background-color .2s, border-color .2s;
    border: 0;
    display: block;
    margin: 35px auto;
    letter-spacing: 5px;
}
.top-container {
    height: 50vh;
}
@keyframes drop-in {
    from {
    opacity: 0;
    transform: translateY(-100px);
    }
    to {
    opacity: 1;
    transform: translate(0px);
    }
}
.original:hover {
    background-color: #f1f1f1;
    border: 0px;
}
.section_btn {
    background-color: rgba(25, 17, 11, .2);
    border-color: #fff;
    border: 1px solid #FFF;
    backdrop-filter: blur(2px);
    color: #FFF;
    font-weight: 400;
    padding: 16px 30px;
    width: -moz-fit-content;
    width: fit-content;
    font-size: 15px;
    text-transform: uppercase;
    letter-spacing: 1px;
    display: block;
    margin: auto;
    margin-top: 30px;
    position: relative;
    overflow: hidden;
    width: 100%;
    max-width: 100px;
}
.section_btn:hover {
    background: #00000029;
    color: #FFF;
    border: 1px solid #FFF;
    /* background: linear-gradient(90deg, #E4E4E4 0%, #FFF 100%); */
}
.section_btn div {
    width: 100%;
    float: left;
    display: flex;
    align-items: center;
    position: relative;
}
.section_btn div p {
    margin: 0;
    margin-left: 7px;
    transition: all 0.4s;
}
.section_btn:hover div p {
    margin-left: -6px;
}
.section_btn div img {
    width: 20px;
    margin-left: 7px;
    display: none;
}
.section_btn div::after {
    content: '';
    background-image: url('../assets/icons/chevron-1.svg');
    position: absolute;
    width: 20px;
    height: 20px;
    top: -2px;
    right: -12px;
    background-size: cover;
    opacity: 0;
    transition: all 0.4s;
}
.section_btn:hover div::after {
    opacity: 1;
}
.parallax-section {
    /* background: #000; */
    height: 100vh;
    overflow: hidden;
    position: relative;
}
.parallax-section::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 2;
    background-image: linear-gradient(0deg, #000000d1 0, transparent);
    transition: opacity .3s cubic-bezier(.39, .575, .565, 1);
    /*  height: 50vw; */
}
.head-text {
    position: absolute;
    bottom: 60px;
}
.parallax-section .parallax-content {
    -webkit-box-align: center;
    -moz-box-align: center;
    -o-box-align: center;
    -ms-flex-align: center;
    -webkit-align-items: center;
    align-items: center;
    color: #fff;
    display: -webkit-box;
    display: -moz-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: box;
    display: flex;
    font-size: 2rem;
    letter-spacing: 0.1em;
    -webkit-box-pack: center;
    -moz-box-pack: center;
    -o-box-pack: center;
    -ms-flex-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    height: 100%;
    position: relative;
    z-index: 2;
}
.parallax-section .parallax-image {
    background-repeat: no-repeat;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    background-size: cover;
    height: 100%;
    left: 0;
    opacity: 1.5;
    -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)";
    filter: alpha(opacity=50);
    position: absolute;
    top: 0;
    -webkit-transform: translateZ(0);
    -moz-transform: translateZ(0);
    -o-transform: translateZ(0);
    -ms-transform: translateZ(0);
    transform: translateZ(0);
    width: 100%;
    z-index: 1;
}
.letters {
    display: flex;
    justify-content: center;
    letter-spacing: 10px;
}
.text.sl-txt{
    display: flex;
    justify-content: center;
    left: 0px;
}
a.section_btn.sale-btn {
  margin-top: 0;
}
.img-sale {
    width: 100%;
    height: 100%;
    object-fit: cover;
}
.marquee-box {
    position: relative;
    width: 100%;
    height: 100vh;
}
.marquee {
    position: absolute;
    display: flex;
    background: #FFF200;
    color: #000;
    width: 100% !important;
    padding: 10px 0;
    overflow: hidden;
}
.marquee-text {
    padding: 0 20px;
    font-weight: 700;
    white-space: nowrap;
    animation-duration: 1.5s;
    animation-timing-function: linear;
    animation-iteration-count: infinite;
}
.marquee--horizontal-top {
    top: 0;
    left: 0;
    z-index: 1;
}
.marquee--horizontal-top .marquee-text {
    animation-name: marquee--right;
}
.marquee--horizontal-bottom {
    bottom: 0;
    left: 0;
    transform: rotate(0deg);
    z-index: 1;
}
.marquee--horizontal-bottom .marquee-text {
    animation-name: marquee--left;
}
.marquee--vertical-right {
    right: 0;
    top: 0;
    transform: translateX(100%) rotate(90deg);
    transform-origin: 0 0;
    overflow: hidden;
    width: 50% !important;
}
.marquee--vertical-right .marquee-text {
    animation-name: marquee--right;
}
.marquee--vertical-left {
    left: 0;
    top: 0;
    transform: translateX(-100%) rotate(-90deg);
    transform-origin: right 0;
    overflow: hidden;
    width: 50% !important;
}
.knw-more {
    width: 13%;
    bottom: 210px;
    font-size: 15px;
}
.knw-txt {
    letter-spacing: 5px !important;
}
.marquee--vertical-left .marquee-text {
    animation-name: marquee--right;
}
@keyframes marquee--left {
    0% {
    transform: translate(0, 0);
    }
    100% {
        transform: translate(-100%, 0);
    }
}
@keyframes marquee--right {
    0% {
        transform: translate(-100%, 0);
    }
    100% {
        transform: translate(0%, 0);
    }
}
label {
    top: 10px;
    display: inline-block;
    padding: 7px 10px;
    background-color: transparent;
    cursor: pointer;
    margin: 10px;
    z-index: 3;
    position: fixed;
}
.bar {
    display: block;
    background-color: #000;
    width: 8px;
    height: 7px;
    border-radius: 100px;
    margin: 5px auto;
}
.humb_menu_btn {
    cursor: pointer;
    display: flex;
    align-items: center;
    opacity: 0;
    width: 2%;
}
.user_action_dv {
    width: 4%;
}
img.menu-icon {
    width: 6%;
    margin-left: 23px;
    margin-top: 10px;
}
aside.sf-sidebar__aside {
    z-index: 4;
}
.video-container {
    position: relative;
    width: 100%;
    height: 100%;
}
.video-abs {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

img.play-img {
    width: 50px;
    position: absolute;
    bottom: 4px;
    left: 0px;
    cursor: pointer;
}
img.pause-img {
    width: 50px;
    position: absolute;
    bottom: 4px;
    left: 0px;
    cursor: pointer;
}
button.video-control {
    border: 0;
    background-color: #0000;
}
.video-control.show {
    display: block;
}
img.mute_icon {
    position: absolute;
    right: 25px;
    width: 24px;
    bottom: 15px;
    cursor: pointer;
}
img.unmute_icon {
    position: absolute;
    right: 25px;
    width: 24px;
    bottom: 15px;
    cursor: pointer;
}
.video-control:not(.playing) .video-control-play, .video-control.playing .video-control-pause {
    display: none;
}
.user_icons {
    width: 22px;
}
.shop_icons {
    width: 22px;
}
.parallax-content.sale {
  display: flex;
  justify-content: center;
}
@media only screen and (min-device-width: 992px) and (max-device-width: 1199px) {
    .frame {
        max-width: 95% !important;
        border: 26px yellow solid !important;
    }
    .div_logo {
        width: 96%;
    }
    .user_action_dv {
        width: 7%;
    }
    .marquee-box{
        height: 93vh;
    }
}
@media only screen and (min-device-width: 768px) and (max-device-width: 991px) {}
@media only screen and (min-device-width: 1200px) and (max-device-width: 1280px) {
  .frame {
    max-width: 97%  !important;
  }
}
@media only screen and (min-device-width: 1281px) and (max-device-width: 1369px) {

    .marquee--vertical-left,
    .marquee--vertical-right {
    width: 46% !important;
    }
  .frame {
    max-width: 97% !important;
  }
}
@media only screen and (min-device-width: 1370px) and (max-device-width: 1440px) {
    .frame {
    max-width: 97% !important;
    border: 22px solid yellow !important;
    }
    .div_logo {
    width: 93%;
    }
    .user_action_dv {
    width: 5%;
    }
}
@media only screen and (min-device-width: 1441px) and (max-device-width: 1536px) {
    .marquee--vertical-left,
    .marquee--vertical-right {
    width: 46% !important;
    }
    .user_action_dv {
    width: 5%;
    }
    .div_logo {
    width: 93%;
    }
}
@media only screen and (min-device-width: 1537px) and (max-device-width: 1600px) {
    .marquee--vertical-left,
    .marquee--vertical-right {
    width: 46% !important;
    }
}
.frame {
--duration: 30s;
--size: 80vw;
--characters: 10;
--font-size: 25px;
--font-weight: 600;
--delay-character: 0.2s;
}
.frame {
max-width: 98%;
max-height: 95vh;
margin: 0 auto;
border: 20px yellow solid;
position: relative;
box-shadow: inset 0 0 0 20px yellow;
background: url('../assets/home/marquee_img.png') no-repeat center;
background-size: cover;
transition: ease all 0.3s;
z-index: 3;
}
.text {
  transform: translate(calc(calc(var(--font-size) * -1) / 2),
      calc(calc(var(--font-size) * -1) / 2));
  position: relative;
  height: 100%;
  transition: ease all 0.3s;
}
.frame .text > span {
  font-size: var(--font-size);
  display: inline-block;
  text-align: center;
  width: var(--font-size);
  animation: frameMove var(--duration) linear infinite;
  position: absolute;
  transition: ease all 0.3s;

  @for $i from 1 through 1000 {
    &:nth-of-type(#{$i}) {
      animation-delay: calc(var(--delay-character) * #{$i});
    }
  }
}
@keyframes frameMove {
    0% {
    top: 0;
    left: 0;
    transform: rotate(0deg);
    }

    24% {
    top: 0;
    left: 100%;
    transform: rotate(0deg);
    }

    25% {
    transform: rotate(90deg);
    }

    49% {
    top: 100%;
    left: 100%;
    transform: rotate(90deg);
    }

    50% {
    transform: rotate(180deg);
    }

    74% {
    top: 100%;
    left: 0%;
    transform: rotate(180deg);
    }

    75% {
    transform: rotate(270deg);
    }

    99% {
    top: 0%;
    left: 0%;
    transform: rotate(270deg);
    }

    100% {
    transform: rotate(360deg);
    }
}


@media only screen and (min-device-width: 768px) and (max-device-width: 991px) {

  .frame{
    max-width: 95%;
  }
  .frame .text span {
      font-size: 16px;
  }
  .text.sl-txt {
    left: 0;
  }
}

@media only screen and (min-device-width: 320px) and (max-device-width: 767px) {
  .fold_main .parallax-section {
    padding:0 20px;
  }
  h2.text{
    text-align: center;
    font-size: 24px;
    transform: translateZ(0px) scale(1);
  }
  .section_btn {
    max-width: 79px;
    font-size: 12px;
    padding: 15px 18px;
  }
  .section_btn div:after {
    width: 17px;
    height: 17px;
    top: -3px;
    right: -10px;
  }
  .frame{
    max-width: 95%;
    border: 10px yellow solid;
    position: relative;
    -webkit-box-shadow: inset 0 0 0 10px yellow;
    box-shadow: inset 0 0 0 10px yellow;
    box-shadow: inset 0 0 0 10px yellow;
  }
  .frame .text span {
    font-size: 12px;
    padding-top: 9px;
    padding-bottom: 5px;
  }
  .text.sl-txt {
    left: 0;
  }
}

/* Cstm CSS End here */
</style>
